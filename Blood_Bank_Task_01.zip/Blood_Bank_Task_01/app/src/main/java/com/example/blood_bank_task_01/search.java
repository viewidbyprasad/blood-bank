package com.example.blood_bank_task_01;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class search extends AppCompatActivity {

    SearchView searchView;
    ListView myList;
    ArrayList<String>  arrayList;
    ArrayAdapter<String> adapter;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search2);

        searchView = findViewById(R.id.search);
        myList = findViewById(R.id.list);

        arrayList = new ArrayList<>();
        arrayList.add("Name : - KIRAN MANKAR    Contact No :- 9665840496 BLOOD GROUP :- A+");
        arrayList.add("Name : - PRASAD UKE      Contact No :- 9665140463 BLOOD GROUP :- O+");
        arrayList.add("Name : - GANESH MANKAR   Contact No :- 9575958601 BLOOD GROUP :- B+");
        arrayList.add("Name : - OMIKA MANKAR    Contact No :- 9665140463 BLOOD GROUP :- B");
        arrayList.add("Name : - PRASAD MANKAR   Contact No :- 9665140463 BLOOD GROUP :- O");
        arrayList.add("Name : - DIPAK SHENDE    Contact No :- 4567548483 BLOOD GROUP :- A+");
        arrayList.add("Name : - RAHUL MANKAR    Contact No :- 1556185285 BLOOD GROUP :- O");
        arrayList.add("Name : - YASH BAWANTHADE Contact No :- 9665140463 BLOOD GROUP :- O+");
        arrayList.add("Name : - DEWA BAWANTHADE Contact No :- 7157525713 BLOOD GROUP :- O");
        arrayList.add("Name : - MADAN VADIYA    Contact No :- 9665140463 BLOOD GROUP :- B+");
        arrayList.add("Name : - SHRADDHA UKE    Contact No :- 2349876987 BLOOD GROUP :- A+");
        arrayList.add("Name : - HARSHAL MANKAR  Contact No :- 9234563453 BLOOD GROUP :- O");
        arrayList.add("Name : - PRASAD VAIDYA   Contact No :- 7418529696 BLOOD GROUP :- B");
        arrayList.add("Name : - SACHIN RAHANE   Contact No :- 7894561230 BLOOD GROUP :- B+");
        arrayList.add("Name : - VANMALA MANKAR  Contact No :- 9665140463 BLOOD GROUP :- A+");
        arrayList.add("Name : - RADHIKA SINGH   Contact No :- 5314647698 BLOOD GROUP :- AB+");
        arrayList.add("Name : - ABHINAV AGARWAL Contact No :- 7106871692 BLOOD GROUP :- O+");
        arrayList.add("Name : - ABHINAV AGARWAL Contact No :- 6738603136 BLOOD GROUP :- B-");
        arrayList.add("Name : - ANKIT MISHRA    Contact No :- 1483241537 BLOOD GROUP :- A+");
        arrayList.add("Name : - RADHIKA SINGH   Contact No :- 9195628089 BLOOD GROUP :- AB+");
        arrayList.add("Name : - VANMALA MANKAR  Contact No :- 2144450348 BLOOD GROUP :- AB-");
        arrayList.add("Name : - TANYA GUPTA     Contact No :- 1473058292 BLOOD GROUP :- AB+");
        arrayList.add("Name : - ABHINAV AGARWAL Contact No :- 4066534804 BLOOD GROUP :- O+");
        arrayList.add("Name : - SUSHANT KUMAR   Contact No :- 2452288294 BLOOD GROUP :- B-");
        arrayList.add("Name : - AMIT SHARMA     Contact No :- 2795921565 BLOOD GROUP :- O-");


        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,arrayList);
        myList.setAdapter(adapter);

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                adapter.getFilter().filter(newText);
                return false;
            }
        });


    }
}