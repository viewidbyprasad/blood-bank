package com.example.blood_bank_task_01;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Register extends AppCompatActivity {

    //DATABASE CONNECTIONS
    DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReferenceFromUrl("https://blood-bank-task01-default-rtdb.firebaseio.com/");


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        final EditText FirstName = findViewById(R.id.fname);
        final EditText LastName = findViewById(R.id.lname);
        final EditText MobileNumber = findViewById(R.id.phone);
        final EditText Email = findViewById(R.id.email);
        final EditText Username = findViewById(R.id.username);
        final EditText Password = findViewById(R.id.password);
        final EditText Conform_password = findViewById(R.id.conform_password);
        final EditText pincode = findViewById(R.id.pincode);
        final Button RegisterButton = findViewById(R.id.loginbutton);
        final TextView RegisterLink = findViewById(R.id.registernowButton);

        RegisterButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //GET DATA FROM USER
                final String userfirstname = FirstName.getText().toString();
                final String UserLastName = LastName.getText().toString();
                final String UserMobileNumber = MobileNumber.getText().toString();
                final String UserEmail = Email.getText().toString();
                final String User_Username = Username.getText().toString();
                final String UserPassword = Password.getText().toString();
                final String User_conform_Password = Conform_password.getText().toString();
                final String Userpincode = pincode.getText().toString();

                if (userfirstname.isEmpty() || UserLastName.isEmpty() || UserMobileNumber.isEmpty() || UserEmail.isEmpty() || User_Username.isEmpty() || UserPassword.isEmpty() || User_conform_Password.isEmpty() || Userpincode.isEmpty() )
                {

                    Toast.makeText(Register.this, "Please Fill the Information ", Toast.LENGTH_SHORT).show();

                }

                // CHECK PASSWORD ARE MATCHED OR NOT
                /*else if (UserPassword.equals(User_conform_Password))
                {
                    Toast.makeText(Register.this, "Password Are Not Same", Toast.LENGTH_SHORT).show();
                }*/
                else {
                    databaseReference.child("user").addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            //CHECK USERNAME ARE ALREADY AVAILABLE OR NOT
                            if (snapshot.hasChild(User_Username))
                            {
                                Toast.makeText(Register.this, "User Name Not Available", Toast.LENGTH_SHORT).show();
                            }
                            else {
                                //SENDING DATA
                                //UNIQUE IDENTITY IS USERNAME
                                databaseReference.child("user").child(User_Username).child("userfirstname").setValue(userfirstname);
                                databaseReference.child("user").child(User_Username).child("userlastname").setValue(UserLastName);
                                databaseReference.child("user").child(User_Username).child("usermobilenumber").setValue(UserMobileNumber);
                                databaseReference.child("user").child(User_Username).child("useremail").setValue(UserEmail);
                                databaseReference.child("user").child(User_Username).child("userpassowrd").setValue(User_conform_Password);
                                databaseReference.child("user").child(User_Username).child("useraddress").setValue(Userpincode);

                                Toast.makeText(Register.this, "User Register Successfully", Toast.LENGTH_SHORT).show();
                                finish();
                            }
                        }
                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                    });

                }
            }
        });

       RegisterLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}