package com.example.blood_bank_task_01;

import java.util.Random;

public class RandomNumberGenerator {

    public static int generateRandomNumber() {
        Random random = new Random();
        int randomNumber = random.nextInt(10000) + 1;
        return randomNumber;
    }
}
